# Claude Terminal — WP Page Change Handover (Feedback v1)

Target:
- Page edit URL: https://yokehealth.com/wp-admin/post.php?post=4148&action=edit
- Goal: apply Feedback 1–5 without breaking layout, and without touching Awards/Testimonial blocks.

Use:
- CHANGELOG_FEEDBACK.md = exact required changes
- EDITOR_TERMS.md = WordPress/ACF terms to use in terminal prompts
- TERMINAL_PROMPT_BLOCK.txt = copy/paste into Claude Code terminal
- VERIFY_CHECKLIST.md = quick QA after changes
