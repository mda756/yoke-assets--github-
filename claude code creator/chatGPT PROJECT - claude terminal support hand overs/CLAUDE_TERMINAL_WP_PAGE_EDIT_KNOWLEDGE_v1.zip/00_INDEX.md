# Claude Terminal — WordPress Page Edit Pack (v1)

Use this pack to update an existing WordPress draft page via Claude Code (terminal) using the WP REST API.

Target page (given by user):
- wp-admin edit URL: https://yokehealth.com/wp-admin/post.php?post=4148&action=edit
- Post/Page ID: 4148

Primary outputs:
1) PAGE_COPY.md (copy to paste into ACF WYSIWYG fields)
2) API_COMMANDS.ps1 (PowerShell commands to: verify auth, verify ACF exposure, update title, update content)
3) FIELD_MAPPING_TEMPLATE.md (fill this once from ACF UI; then API edits become deterministic)

Hard rules:
- Do NOT touch Awards blocks or Testimonials blocks.
- Preserve layout + styling; only replace text inside existing fields.
